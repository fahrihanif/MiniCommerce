namespace MiniCommerce.API.Services.Accounts;

public class AccountErrors
{
    
}