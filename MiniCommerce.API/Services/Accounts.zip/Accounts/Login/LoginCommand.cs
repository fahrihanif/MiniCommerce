using MiniCommerce.API.Abstractions.Messages;

namespace MiniCommerce.API.Services.Accounts.Login;

public class LoginCommand(string Email, string Password) : ICommand<LoginResponse>;