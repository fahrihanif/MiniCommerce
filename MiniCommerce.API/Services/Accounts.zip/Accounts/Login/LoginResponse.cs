namespace MiniCommerce.API.Services.Accounts.Login;

public record LoginResponse(string AccessToken);